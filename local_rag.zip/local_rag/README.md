Run: uvicorn main:app --port 7866
Then visit 127.0.0.1:7866